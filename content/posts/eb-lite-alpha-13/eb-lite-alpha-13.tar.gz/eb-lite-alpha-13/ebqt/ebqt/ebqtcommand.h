/***************************************************************************
                          ebqtcommand.h  -  description
                             -------------------
    begin                : Sat Jul 27 2002
    copyright            : (C) 2002-3 by Chris Boyle
    email                : cmb@everybuddy.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   In addition, when you distribute EbQt binaries under section 3 of     *
 *   the GPL, I waive the requirement for the source code of Qt to be      *
 *   available. Source for all other parts is still required.              *
 *                                                                         *
 ***************************************************************************/

#ifndef EBQTCOMMAND_H
#define EBQTCOMMAND_H

//#include <qvaluelist.h>
#include <qstringlist.h>

#include "ebqt.h"

/**
 * typedef to QStringList. nuff said.
 * @author Chris Boyle
 */

typedef QStringList EbQtCommand;
 
//old
/*
 * The only real difference between an EbQtCommand and a QValueList<QByteArray>
 * is that you can do command << "a string" (or a QString). Also, operator[]
 * returns a QString (UTF-8).
 *
 * @author Chris Boyle
 */


/*class EbQtCommand : public QStringList  //QValueList<QByteArray>
{
public:
	EbQtCommand() : QStringList() {}
	~EbQtCommand() {}
	//EbQtCommand(const EbQtCommand& c) : QValueList<QByteArray>(c) {}
	EbQtCommand(const EbQtCommand& c) : QStringList(c) {}
	//EbQtCommand(const QValueList<QByteArray>& l) : QValueList<QByteArray>(l) {}
	EbQtCommand(const QStringList & l) : QStringList(l) {}
	EbQtCommand(const char *s) { (*this) << s; }
	EbQtCommand(const QString &s) { (*this) << s; }
//	QString operator[](int i) const { return QString::fromUtf8(
//		QValueList<QByteArray>::operator[](i)); }
//	EbQtCommand & operator<<(const char *s) {
//		return (EbQtCommand&)QValueList<QByteArray>::operator<<(
//			(new QByteArray())->duplicate(s, qstrlen(s))); }
//	EbQtCommand & operator<<(const QString &s) {
//		return (EbQtCommand&)QValueList<QByteArray>::operator<<(
//			(new QByteArray())->duplicate(s.ascii(), s.length())); }
};
*/
#endif
