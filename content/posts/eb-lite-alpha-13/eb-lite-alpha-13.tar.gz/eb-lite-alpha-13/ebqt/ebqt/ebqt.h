/***************************************************************************
                          ebqt.h  -  description
                             -------------------
    begin                : Fri Jul 26 2002
    copyright            : (C) 2002-3 by Chris Boyle
    email                : cmb@everybuddy.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   In addition, when you distribute EbQt binaries under section 3 of     *
 *   the GPL, I waive the requirement for the source code of Qt to be      *
 *   available. Source for all other parts is still required.              *
 *                                                                         *
 ***************************************************************************/

#ifndef EBQT_H
#define EBQT_H

// debugging: define this to get all traffic to and from the core on stderr
#define EBQT_TRANSCRIPT

// some messages appear briefly in the status bar, this defines "briefly" in ms
#define EBQT_STATUSBAR_DELAY 3000

// distance apart when cascading conv windows (on turning off conv tabbing)
// set to 0, 0 to have them piled on top of each other
#define EBQT_CASCADE_GAP_X 32
#define EBQT_CASCADE_GAP_Y 32

// basically whether to give timestamps a column in conversations
#define  EBQT_CONV_USE_TABLE
// proportion of default size that '+1' adds
#define EBQT_CONV_FONT_STEP_SIZE  0.25
// allowable range for font size=[+-]N
#define EBQT_CONV_FONT_MAX_STEPS  3
#define EBQT_CONV_FONT_MIN_STEPS -4

#define EBQT_DEFAULT_PORT	18234
#define EBQT_COOKIE_LENGTH	8

#define EBQT_DEFAULT_LAUNCH_CMD	"eb-lite -f %1 %2 -n -q"

#define EBQT_AUTHOR_NAME "Chris Boyle"
#define EBQT_AUTHOR_EMAIL "cmb@everybuddy.com"
#define EBQT_AUTHOR EBQT_AUTHOR_NAME " <" EBQT_AUTHOR_EMAIL ">"
#define EBQT_AUTHOR_HTML EBQT_AUTHOR_NAME " &lt;<a href=\"mailto:" \
EBQT_AUTHOR_EMAIL "\">" EBQT_AUTHOR_EMAIL "</a>&gt;"


#endif

