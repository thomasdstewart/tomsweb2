/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename slots use Qt Designer which will
** update this file, preserving your code. Create an init() slot in place of
** a constructor, and a destroy() slot in place of a destructor.
*****************************************************************************/


void EbQtMainWinUI::init()
{
	localAcctsView->verticalHeader()->hide();
	localAcctsView->setLeftMargin(0);
	localAcctsView->setColumnReadOnly(0, FALSE);
	localAcctsView->setColumnReadOnly(1, TRUE);
	localAcctsView->setColumnReadOnly(2, TRUE);
	localAcctsView->setColumnReadOnly(3, TRUE);
	localAcctsView->setColumnReadOnly(4, TRUE);
	localAcctsView->setColumnWidth(1,
		(localAcctsView->horizontalHeader()->height()*3)/4);
	localAcctsView->setColumnWidth(2,
		(localAcctsView->horizontalHeader()->height()*3)/4);
	localAcctsView->horizontalHeader()->setResizeEnabled(FALSE, 1);
	localAcctsView->horizontalHeader()->setResizeEnabled(FALSE, 2);
	localAcctsView->horizontalHeader()->setClickEnabled(FALSE);
	localAcctsView->setHScrollBarMode(QScrollView::AlwaysOff);
	localAcctsView->setColumnStretchable(0, TRUE);
	localAcctsView->setColumnStretchable(3, TRUE);
	localAcctsView->setColumnStretchable(4, TRUE);
	
	(new QVBoxLayout(acctPrefsFrame, 0))->setAutoAdd(TRUE);
	
	launchCmdEdit->installEventFilter(this);
	addrCombo->installEventFilter(this);
	cookieLabel->setBuddy(cookieFrame);
}

void EbQtMainWinUI::changeHow( int )
{

}

void EbQtMainWinUI::changeWho( int )
{

}

void EbQtMainWinUI::showAboutBox()
{

}

void EbQtMainWinUI::toggleStatusBar( bool )
{

}

void EbQtMainWinUI::toggleToolBar( bool )
{

}

void EbQtMainWinUI::tryConnect()
{

}


bool EbQtMainWinUI::loadCookie()
{
	return FALSE;
}


void EbQtMainWinUI::tryShowPrefs()
{

}

void EbQtMainWinUI::trySignOn( bool )
{

}

void EbQtMainWinUI::tryChangeLocalStatus( int, int )
{

}


void EbQtMainWinUI::aboutQt()
{

}

void EbQtMainWinUI::tryAdd()
{

}

void EbQtMainWinUI::tryRemove()
{

}

void EbQtMainWinUI::tabChanged( QWidget * )
{

}

void EbQtMainWinUI::selectLocalAcct( int, int )
{

}

void EbQtMainWinUI::trySaveConfig()
{

}

void EbQtMainWinUI::trySignOff( bool )
{

}

void EbQtMainWinUI::tryAway( bool )
{

}

void EbQtMainWinUI::launchAndConnect()
{

}




void EbQtMainWinUI::tryIgnore( bool )
{

}

void EbQtMainWinUI::startRename()
{

}

void EbQtMainWinUI::makeAcctPreferred()
{

}


void EbQtMainWinUI::localAcctRMB( int, int, const QPoint & )
{

}


void EbQtMainWinUI::tryJoinGroup()
{

}


void EbQtMainWinUI::tryOpenConv()
{

}

void EbQtMainWinUI::toggleConvsInTabs( bool )
{

}

void EbQtMainWinUI::toggleGroupConvsInTabs( bool )
{

}

void EbQtMainWinUI::doCascadeConvs()
{

}

void EbQtMainWinUI::doCascadeGroupConvs()
{

}


void EbQtMainWinUI::resetLaunchCmd()
{

}

void EbQtMainWinUI::killLaunchedCore()
{

}

void EbQtMainWinUI::disconnectCore()
{

}


void EbQtMainWinUI::setConvsUndocked(bool)
{

}

void EbQtMainWinUI::setConvsDockLeft(bool)
{

}

void EbQtMainWinUI::setConvsDockRight(bool)
{

}
