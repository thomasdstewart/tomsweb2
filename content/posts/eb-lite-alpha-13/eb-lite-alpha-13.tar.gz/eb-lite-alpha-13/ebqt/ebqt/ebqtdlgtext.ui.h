/****************************************************************************
** ui.h extension file, included from the uic-generated form implementation.
**
** If you wish to add, delete or rename functions or slots use
** Qt Designer which will update this file, preserving your code. Create an
** init() function in place of a constructor, and a destroy() function in
** place of a destructor.
*****************************************************************************/

void EbQtDlgText::init()
{
	QVBoxLayout * l = new QVBoxLayout(editFrame, 0, 0);
	l->addWidget(textEdit = new EbQtTextEdit(editFrame, "textEdit"));
	l->activate();
	setTabOrder((QWidget *)(textEdit->textEdit), (QWidget *)ok);
}

void EbQtDlgText::setMessage( const QString & text )
{
	message->setText(text);
}

void EbQtDlgText::setMsgIcon( const QString & pixmap )
{
	typeIcon->setPixmap(pixmap);
}


void EbQtDlgText::setRawMode( bool on )
{
	textEdit->setRawMode(on);
}


void EbQtDlgText::setText( const QString & text )
{
	textEdit->setText(text);
}


QString EbQtDlgText::text()
{
	return textEdit->text();
}
