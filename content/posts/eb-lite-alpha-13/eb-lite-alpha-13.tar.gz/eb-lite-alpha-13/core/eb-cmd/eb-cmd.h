#ifndef __EB_CMD_H__
#define __EB_CMD_H__

void eb_cmd_connect(void);
void eb_cmd_getmsgs(void);
char * eb_cmd_get_group(char * contact);

#endif // __EB_CMD_H__
