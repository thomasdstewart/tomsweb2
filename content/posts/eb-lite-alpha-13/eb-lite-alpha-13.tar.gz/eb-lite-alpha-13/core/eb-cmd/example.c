#include <stdio.h>
#include <stdlib.h>
#include <sys/poll.h>
#include "GUIcomms.h"

// Test program for Everybuddy GUIcomms code

main(int argc, char * argv[])
{
  struct pollfd pfd[2];
  int gui_port=18234;
  int a;
  unsigned char cookie[8];

  printf("Enter cookie: ");
  fflush(stdout);

  for(a=0; a<8; a++)
  {
    int c;
    scanf(" %d", &c);
    cookie[a]=(unsigned char)c;
  }

  if(argc>1)
  {
    gui_port=atoi(argv[1]);
    if(gui_port==0) { gui_port=18234; }
  }

  printf("Connecting...");
  fflush(stdout);
  if(connect_gui_socket("localhost", gui_port, cookie)<0)
  {
    perror("failed");
    exit(1);
  }
  printf("done\n");

  pfd[0].fd=gui_sock;
  pfd[0].events=POLLIN|POLLERR;
  pfd[0].revents=0;
  pfd[1].fd=0;
  pfd[1].events=POLLIN|POLLERR;
  pfd[1].revents=0;

  printf(">> ");
  fflush(stdout);

  while(1)
  {
    poll(pfd, 2, -1);

    if(pfd[0].revents&POLLIN)
    {
      int num_params;
      char ** command=read_gui_message(&num_params);

      if(command==NULL)
      { perror("Incoming dud"); exit(1); }

      printf("Incoming: ");

      for(a=0; a<num_params; a++)
      {
        printf("%s ", command[a]);
      }
      printf("\n>> ");
      fflush(stdout);
      pfd[0].revents=0;
    }

    if(pfd[1].revents&POLLIN)
    {
      int num_params;
      char ** command;

      scanf(" %d", &num_params);
      command=(char **)malloc(num_params * sizeof(char *));

      printf("Message send\n");

      for(a=0; a<num_params; a++)
      {
        command[a]=(char *)malloc(1024);
        scanf(" %s", command[a]);
      }

      send_gui_message(command, num_params);

      for(a=0; a<num_params; a++)
      { free(command[a]); }
      free(command);

      printf(">> ");
      fflush(stdout);
      pfd[1].revents=0;
    }
  }
}
