#ifndef GUICOMMS_H
#define GUICOMMS_H

#ifdef __cplusplus
extern "C" {
#endif

int send_gui_message(char ** command, int num_params);
char ** read_gui_message(int * num_params);
int connect_gui_socket(char * hostname, int port, unsigned char * cookie);
void destroy_command(char ** cmd, int num);

#ifdef __cplusplus
}
#endif

extern int gui_in, gui_out;

#endif // GUICOMMS_H
