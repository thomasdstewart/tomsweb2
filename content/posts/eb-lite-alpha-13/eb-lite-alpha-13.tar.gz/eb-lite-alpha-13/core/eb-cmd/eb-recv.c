#include <stdio.h>
#include <stdlib.h>
#ifndef __MINGW32__
#include <sys/poll.h>
#endif

#include "eb-cmd.h"
#include "GUIcomms.h"

// Send an instant message using Everybuddy

main(int argc, char * argv[])
{
  int a;

  eb_cmd_connect();
  eb_cmd_getmsgs();

  if(argc>1)
  {
    if(strcmp(argv[1], "wait"))
    {
      printf("Usage: eb-recv [wait]\n\tChecks for messages from EB-lite. If \"wait\"\nis specified, stays connected and waits\n for messages\n");
      exit(0);
    }
  } else {
    exit(0);
  }

  while(1)
  {
    char ** rcmd;
    int n;
    rcmd=read_gui_message(&n);
    if(!strcmp(rcmd[0], "holding_message"))
    {
      char * cmd[]={"get_held_messages"};
      send_gui_message(cmd, 1);
      eb_cmd_getmsgs();
    }

    if(!strcmp(rcmd[0], "message_send") || !strcmp(rcmd[0], "message_receive"))
    {
      if(rcmd[0][8]=='s') { printf("Sent to "); }
      printf("%s:\n\t%s\n", rcmd[5], rcmd[6]);
    }

    if(!strcmp(rcmd[0], "notify_3rdperson"))
    {
      printf("<%s>\t%s\n", rcmd[2], rcmd[3]);
    }

    destroy_command(rcmd, n);
  }
}

