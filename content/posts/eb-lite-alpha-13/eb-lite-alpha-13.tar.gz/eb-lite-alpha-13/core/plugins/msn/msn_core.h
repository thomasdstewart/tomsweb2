/* msn_core.h  - prototypes for msn_core.C */
#ifndef MSN_CORE_H
#define MSN_CORE_H

// Error codes
#define MSNERR_SYNTAX_ERROR			200
#define MSNERR_INVALID_PARAMETER		201
#define MSNERR_INVALID_USER			205
#define MSNERR_FQDN_MISSING			206
#define MSNERR_ALREADY_LOGIN			207
#define MSNERR_INVALID_USERNAME			208
#define MSNERR_INVALID_FRIENDLY_NAME		209
#define MSNERR_LIST_FULL			210
#define MSNERR_ALREADY_THERE			215
#define	MSNERR_NOT_ON_LIST			216
#define MSNERR_ALREADY_IN_THE_MODE		218
#define MSNERR_ALREADY_IN_OPPOSITE_LIST		219

#define MSNERR_SWITCHBOARD_FAILED		280
#define MSNERR_NOTIFY_XFR_FAILED		281

#define MSNERR_REQUIRED_FIELDS_MISSING		300
#define MSNERR_NOT_LOGGED_IN			302

#define MSNERR_INTERNAL_SERVER			500
#define MSNERR_DB_SERVER			501
#define MSNERR_FILE_OPERATION			510
#define MSNERR_MEMORY_ALLOC			520

#define MSNERR_SERVER_BUSY			600
#define MSNERR_SERVER_UNAVAILABLE		601
#define MSNERR_PEER_NS_DOWN			602
#define MSNERR_DB_CONNECT			603
#define MSNERR_SERVER_GOING_DOWN		604
#define MSNERR_CREATE_CONNECTION		707
#define MSNERR_BLOCKING_WRITE			711
#define MSNERR_SESSION_OVERLOAD			712
#define MSNERR_USER_TOO_ACTIVE			713
#define MSNERR_TOO_MANY_SESSIONS		714
#define MSNERR_NOT_EXPECTED			715
#define MSNERR_BAD_FRIEND_FILE			717

#define MSNERR_AUTHENTICATION_FAILED		911
#define MSNERR_NOT_ALLOWED_WHEN_OFFLINE		913
#define MSNERR_NOT_ACCEPTING_NEW_USERS		920

class llist_data // inherit it
{
    public:
    virtual ~llist_data() {}
};

class llist
{
  public:
  llist_data * data;
  llist * next;
  llist * prev;

  llist() { data=NULL; next=NULL; prev=NULL; }
  ~llist() { if(data!=NULL) { delete data; } if(next!=NULL) { delete next; } }
};

class char_data : public llist_data
{
  public:
  char * c;
  char_data(char * tc) { c=tc; }
  ~char_data() { if(c!=NULL) { delete c; } }
};

class message : public llist_data // This class encapsulates all that you need to know (tm) about a MSG
{
  public:

  // Raw stuff
  char * header; // MIME
  char * body;

  // Parsed stuff
  char * font;
  char * colour;
  int bold;
  int italic;
  int underline;
  int fontsize;

  char * content; // Content-type

  message() { header=NULL; font=NULL; content=NULL; }
};

class userdata : public llist_data
{
  public:
  char * username;
  char * friendlyname;
  userdata() { username=friendlyname=NULL; }
  ~userdata() { if(username!=NULL) { delete username; } if(friendlyname!=NULL) { delete friendlyname; } }
};

class authdata
{
    public:
    virtual ~authdata() {}
};


class msnconn : public llist_data
{
  public:
  int sock; // Socket (durr...)
  int type; // one of the #defines below
  int ready;
  llist * users; // Users in this session - only for SB connections
  llist * invitations_out; // invitations extended but not responded to
  llist * invitations_in; // invitations received but not responded to
  llist * callbacks;
  authdata * auth;
  void * user_data;
  int synctrid;

  msnconn() { users=NULL; callbacks=NULL; invitations_out=NULL; 
              invitations_in=NULL; user_data = NULL; }
  ~msnconn()
  {
    if(users!=NULL) { delete users; }
    if(invitations_in!=NULL) { delete invitations_in; }
    if(invitations_out!=NULL) { delete invitations_out; }
    if(callbacks!=NULL) { delete callbacks; }
  }
};

#define CONN_NS  1 // Notification Server (also Dispatch, as it does exactly the same thing)
#define CONN_SB  2 // Switchboard Server
#define CONN_FTP 3 // MSN file transfer

class authdata_NS : public authdata
{
  public:
  char * username;
  char * password;

  authdata_NS() { username=password=NULL; }
  ~authdata_NS() { if(username!=NULL) { delete username; delete password; } }
};

class authdata_SB : public authdata
{
  public:
  char * username;
  char * sessionID;
  char * cookie;
  char * rcpt;  // recipient of the below
  message * msg; // to be sent as soon as connection is complete and someone joins
  void * tag; // for SB connections without an initial message

  authdata_SB() { username=sessionID=cookie=NULL; }
  ~authdata_SB()
  { if(username!=NULL) { delete username; delete sessionID; delete cookie; } }
};

class invitation : public llist_data
{
  public:
  int app;
  char * cookie;
  char * other_user;
  msnconn * conn;

  invitation() { cookie=other_user=NULL; }
  ~invitation() { if(cookie!=NULL) { delete cookie; } if(other_user!=NULL) { delete other_user; } }
};

#define APP_FTP 1       // NOTE: this is MSN file transfer, which is NOTHING to do with ordinary FTP!

class invitation_ftp : public invitation
{
  public:
  char * filename;
  long unsigned filesize;
  void * user_data;

  invitation_ftp() { filename=NULL; user_data=NULL; }
  ~invitation_ftp()
    { if(filename!=NULL) { delete filename; } }
};


class authdata_FTP : public authdata
{
  public:
  char * cookie;
  char * username;
  invitation_ftp * inv;
  int fd;
  unsigned long bytes_done;
  int num_ignore;
  int direction;
  int connected;

  authdata_FTP() { cookie=username=NULL; inv=NULL; fd=-1; bytes_done=num_ignore=connected=0; }
  ~authdata_FTP()
  {
    if(cookie!=NULL) { delete cookie; }
    if(username!=NULL) { delete username; }
    if(inv!=NULL) { delete inv; }
  }
};

#define MSNFTP_SEND 1
#define MSNFTP_RECV 2

class callback_data
{};

class callback : public llist_data
{
  public:
  int trid;
  void (*func)(struct msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
  callback_data * data; // just gets passed
};


extern llist * connections;
extern int next_trid;
extern char buf[4096]; // Used for anything temporary

int msn_write(msnconn * conn, const char * data);

void msn_init(msnconn * conn, char * username, char * password);

void msn_show_verbose_error(msnconn * conn, int errcode);

void msn_connect(msnconn * conn, char * server, int port);

void msn_send_ping(msnconn * conn);

void msn_ping_all(void);

void msn_invite_user(msnconn * conn, char * rcpt);

void msn_send_IM(msnconn * conn, char * rcpt, char * msg);

void msn_send_IM(msnconn * conn, char * rcpt, message * msg);

void msn_send_typing(msnconn * conn);

void msn_filetrans_accept(invitation_ftp * inv, const char * dest);

void msn_filetrans_reject(invitation_ftp * inv);

void msn_filetrans_cancel(invitation_ftp * inv);

invitation_ftp * msn_filetrans_send(msnconn * conn, const char * path);

void msn_sync_lists(msnconn * conn, int version);

#define LST_FL  1
#define LST_AL  2
#define LST_BL  4
#define LST_RL  8

#define COMPLETE_BLP 16
#define COMPLETE_GTC 32

// Intermediate steps in synchronisation
class syncinfo : public callback_data
{
  public:

  llist * fl;
  llist * rl;
  llist * al;
  llist * bl;

  unsigned int complete;

  unsigned int lstcnt, lngcnt;

  int serial;

  char blp;
  char gtc;

  syncinfo() { blp='A'; gtc='A'; fl=rl=al=bl=NULL; complete=0; serial=0; }
  ~syncinfo()
  {
    if(fl!=NULL) { delete fl; }
    if(rl!=NULL) { delete rl; }
    if(al!=NULL) { delete al; }
    if(bl!=NULL) { delete bl; }
  }
};

void msn_set_friendlyname(msnconn * conn, char * friendlyname);

void msn_sync_lists(msnconn * conn, int version);
void msn_add_to_list(msnconn * conn, char * list, char * user);
void msn_del_from_list(msnconn * conn, char * list, char * user);
void msn_set_GTC(msnconn * conn, char c);
void msn_set_BLP(msnconn * conn, char c);
void msn_syncdata(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
void msn_check_rl(msnconn * conn, syncinfo * info);

void msn_connect_and_send(msnconn * nsconn, char * dest, char * msg);

void msn_set_state(msnconn * conn, char * state);

// Intermediate steps in switchboard connection:
class conninfo_SB : public callback_data
{
  public:
  authdata_SB * auth;
};

void msn_new_SB(msnconn * nsconn, void * tag);
void msn_request_SB(msnconn * nsconn, char * rcpt, message * msg, void * tag);

void msn_SBconn_2(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
void msn_SBconn_3(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);

void msn_handle_incoming(int sock, int readable, int writable);

void msn_handle_filetrans_incoming(msnconn * conn, int readable, int writable);

void msn_handle_close(int sock);

void msn_handle_default(msnconn * conn, char ** args, int numargs);

void msn_handle_MSG(msnconn * conn, char ** args, int numargs);

void msn_handle_invite(msnconn * conn, char * from, char * friendly, char * mime, char * body);

void msn_handle_new_invite(msnconn * conn, char * from, char * friendly, char * mime, char * body);

void msn_recv_file(invitation_ftp * inv, char * dest);

char * msn_find_in_mime(char * mime, char * header);

void msn_send_file(invitation_ftp * inv, char * msg_body);

void msn_handle_NAK(msnconn * conn, char ** args, int numargs);

void msn_handle_JOI(msnconn * conn, char ** args, int numargs);

void msn_handle_BYE(msnconn * conn, char ** args, int numargs);

void msn_handle_RNG(msnconn * conn, char ** args, int numargs);

void msn_handle_statechange(msnconn * conn, char ** args, int numargs);

void msn_handle_ADD(msnconn * conn, char ** args, int numargs);

void msn_handle_REM(msnconn * conn, char ** args, int numargs);

void msn_handle_BLP(msnconn * conn, char ** args, int numargs);

void msn_handle_GTC(msnconn * conn, char ** args, int numargs);

void msn_handle_REA(msnconn * conn, char ** args, int numargs);

void msn_handle_CHL(msnconn * conn, char ** args, int numargs);

void msn_handle_OUT(msnconn * conn, char ** args, int numargs);



// Intermediate steps in connection:
class connectinfo : public callback_data
{
  public:
  char * username;
  char * password;
  char * cookie;
  connectinfo() { username=password=cookie=NULL; }
  ~connectinfo()
  { if(username!=NULL) { delete username; } if(password!=NULL) { delete password; } if(cookie!=NULL) { delete cookie; } }
};

void msn_connect_2(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
void msn_connect_3(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
void msn_connect_4(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);
void msn_got_passport(msnconn * conn, int code, char * auth);
void msn_connect_5(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);

size_t msn_handle_curl_write(void *ptr, size_t size, size_t nmemb, void  *stream);
size_t msn_handle_curl_header(void *ptr, size_t size, size_t nmemb, void *stream);

// Connecting to switchboards:
void msn_SB_ans(msnconn * conn, int trid, char ** args, int numargs, callback_data * data);

#endif // MSN_CORE_H
