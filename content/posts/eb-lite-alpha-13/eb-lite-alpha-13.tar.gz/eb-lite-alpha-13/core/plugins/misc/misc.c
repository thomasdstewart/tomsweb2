/***************************************************************************
                misc.c - Loads miscellaneous utility stuff
                             -------------------
                     (C) 2002 by the Everybuddy team
                            www.everybuddy.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "plugin_api.h"
 
void eb_rainbow_init(void);
void eb_autotrans_init(void);
 
int misc_init(void);
int misc_finish(void);
 
eb_plugin_info misc_LTX_plugin_info = {
  "Misc plugins",
  "Autotrans, rainbow",
  "",
  "",
  misc_init,
  misc_finish
};

int misc_init(void)
{
  eb_autotrans_init();
  eb_rainbow_init();
  return 0;
}

int misc_finish(void)
{
  return 0;
}
