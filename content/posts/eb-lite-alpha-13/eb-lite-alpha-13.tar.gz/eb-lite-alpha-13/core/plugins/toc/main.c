#include <stdio.h>
#include "libtoc.h"

int main()
{
  printf("Hello\n");

  return 0;
}
