// accounts.h - headers for accounts.c
#ifndef __ACCOUNTS_H__
#define __ACCOUNTS_H__

#include "elist.h"
#include "contactlist.h"
#include "services.h"

#ifdef __cplusplus
extern "C" {
#endif

void load_local_accounts(void);
void map_orphaned_accounts(void);

extern EList * local_accounts; // type eb_local_account

#ifdef __cplusplus
}
#endif

#endif // __ACCOUNTS_H__
