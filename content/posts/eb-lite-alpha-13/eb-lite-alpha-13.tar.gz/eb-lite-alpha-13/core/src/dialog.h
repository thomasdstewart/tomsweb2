// dialog.h
#ifndef __DIALOG_H__
#define __DIALOG_H__

#ifdef __cplusplus
extern "C" {
#endif

void eb_show_error(char * message, char * title);
void eb_show_list_dialog(char * message, char * title, char **list, void (*callback)(char * response, void * tag), void * tag);
void eb_show_yesno_dialog(char * message, char * title, int default_result, void (*callback)(int response, void * tag), void * tag);
void eb_show_text_dialog(char * message, char * title, char * value, int html, void (*callback)(char * response, void * tag), void * tag);

#ifdef __cplusplus
}
#endif

#endif // __DIALOG_H__
