//staticmods.h

#ifndef __STATICMODS_H__
#define __STATICMODS_H__

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef STATIC_MSN
extern int msn_plugin_init();
extern int msn_plugin_finish();
#endif
#ifdef STATIC_YAHOO
extern int yahoo_plugin_init();
extern int yahoo_plugin_finish();
#endif
#ifdef STATIC_IRC
extern int irc_init();
extern int irc_finish();
#endif
#ifdef STATIC_JABBER
extern int jabber_init();
extern int jabber_finish();
#endif

#endif
