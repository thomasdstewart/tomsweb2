#ifndef __BASE64_H__
#define __BASE64_H__

// Prototypes for base64.c, Peter Samuelson's base64 {en|de}coder

size_t encode_base64(char *out, const char *in, size_t in_len);

/*
 * Decode MIME BASE-64 (see RFC 1341), "in situ"
 * This is possible because the output is always shorter than the input
 * Returns the final length of the buffer, 0 for invalid char(s)
 */
size_t decode_base64(char *buf, size_t len)

#endif
