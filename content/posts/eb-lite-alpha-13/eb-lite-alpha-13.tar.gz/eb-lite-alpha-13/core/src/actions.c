/***************************************************************************
                    actions.c - Generic action code
                             -------------------
                     (C) 2002 by the Everybuddy team
                            www.everybuddy.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "actions.h"

EList * eb_group_actions=NULL;
EList * eb_contact_actions=NULL;
EList * eb_buddy_actions=NULL;
EList * eb_general_actions=NULL;


eb_action * eb_create_action(char * name, eb_action_callback callback)
{
  eb_action * action=(eb_action *)malloc(sizeof(eb_action));

  action->name=strdup(name);
  action->callback=callback;
  
  return action;
}

void eb_free_action(eb_action * action)
{
  free(action->name);
}

