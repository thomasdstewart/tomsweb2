// stringmap.h

#ifndef __STRINGMAP_H__
#define __STRINGMAP_H__

#include "elist.h"
typedef EList * eb_string_map;

typedef struct _eb_string_map_entry
{
  char * name;
  void * value;
} eb_string_map_entry;

#ifdef __cplusplus
extern "C" {
#endif

void eb_string_map_put(eb_string_map * map, char * name, void * value);
void * eb_string_map_get(eb_string_map map, char * name);
void eb_string_map_remove_name(eb_string_map * map, char * name);
void eb_string_map_remove_value(eb_string_map * map, void * value);

#ifdef __cplusplus
}
#endif

#endif // __STRINGMAP_H__

