// globals.h

#ifndef __GLOBALS_H__
#define __GLOBALS_H__

#include "debug.h"

// These are actually declared in gui_comms.c, for
// no particular reason...
extern char * away_msg;
extern char * away_short;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __MINGW32__
#define mkdir(x,y) _mkdir(x)
#define write(a,b,c) send(a,b,c,0)
#define read(a,b,c)  recv(a,b,c,0)

#ifdef __IN_PLUGIN
__declspec(dllimport)
#endif
#endif

// misc_cb.c
void eb_register_misc_cb(void);

void eb_phonehome_cb(int response, void * tag);

#ifdef __cplusplus
}
#endif

#endif // __GLOBALS_H__
