/***************************************************************************
                staticmods.c - Loads statically-compiled plugins
                             -------------------
                     (C) 2002 by the Everybuddy team
                            www.everybuddy.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

// staticmods.c - this file is provided merely for utility purposes

#include "plugin.h"
#include "staticmods.h"

void load_static_mods(void)
{
#if STATIC_MSN || STATIC_msn
  msn_plugin_init();
#endif
#if STATIC_IRC || STATIC_irc
  eb_irc_init();
#endif
#if STATIC_TOC || STATIC_toc
  eb_toc_init();
#endif
#if STATIC_YAHOO || STATIC_yahoo
  yahoo_plugin_init();
#endif
#if STATIC_JABBER || STATIC_jabber
  eb_jabber_init();
#endif
#if STATIC_MISC || STATIC_misc
  eb_autotrans_init();
  eb_rainbow_init();
#endif
}
